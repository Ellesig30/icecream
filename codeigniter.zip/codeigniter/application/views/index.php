<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
	<div class="registration-form">
		<?php echo form_open('register'); ?>
			<div class="container">
				<h1>Register</h1>
				<div class="form">
					<lable>Username</lable>
					<input type="text" name="username" class="input-form" value="<?php echo set_value('username'); ?>">
					<?php echo form_error('username', '<div class="error">','</div>'); ?>
				</div>
				<div class="form">
					<lable>Password</lable>
					<input type="password" name="password" class="input-form">
					<?php echo form_error('password', '<div class="error">','</div>'); ?>
				</div>
				<div class="form">
					<lable>Name</lable>
					<input type="text" name="name" class="input-form" value="<?php echo set_value('name'); ?>">
					<?php echo form_error('name', '<div class="error">','</div>'); ?>
				</div>
				<div class="form btn-submit">
					<input type="submit" name="submit" class="input-form" value="register">
				</div>
			</div>
		</form>
	</div>
</body>
</html>