<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/style.css'); ?>">
</head>
<body>
	<div class="registration-form">
		<h1>Dashboard</h1>
		<a href="<?php echo base_url('logout'); ?>">Logout</a>
		<h3>All users</h3>
		<table>
			<thead>
				<tr>
					<th>Username</th>
					<th>Name</th>
					<th colspan="2">Action</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($all as $user){ ?>
					<tr>
						<td><?php echo $user->username; ?></td>
						<td><?php echo $user->name; ?></td>
						<td>
							<a href="<?php echo base_url('user/delete/'. $user->id) ?>" onclick="return confirm('Are you sure you want to delete?')">Delete</a>
						</td>
						<td>
							<a href="<?php echo base_url('user/update/'. $user->id) ?>">Update</a>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>
	</div>
</body>
</html>