<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainController extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Users');
		$this->load->library('form_validation');
	}

	public function index() {
		$this->load->view('index');
	}

	public function register() {
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('name', 'Name', 'required');

		if($this->form_validation->run()) {
			// save
			$arr = array(
				'username' => $this->input->post('username'),
				'password' => $this->input->post('password'),
				'name' 	   => $this->input->post('name')
			);
			if($this->Users->save($arr)) {
				echo "Saved";
			} else {
				echo "Error";
			}
		} else {
			$this->load->view('index');
		}
	}


	public function login() {
		$this->load->view('login');
	}

	public function login_submit() {
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if($this->form_validation->run()) {
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			if($this->Users->login($username, $password)) {
				return redirect(base_url('dashboard'));
			} else {
				echo "Incorrect username or password";
			}

		} else {
			$this->load->view('login');
		}
	}
}