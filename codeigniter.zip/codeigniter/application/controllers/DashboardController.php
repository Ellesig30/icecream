<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class DashboardController extends CI_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->model('Users');
	}

	public function dashboard() {
		if (!is_null($this->session->userdata('user'))) {
			
			$users = $this->Users->all();
			$this->load->view('dashboard', array('all' => $users));


		} else {
			return redirect(base_url('login'));
		}
	}

	public function deleteUser($id) {
		if ($this->Users->delete($id)) {
			return redirect(base_url('dashboard'));
		} else {
			echo "Unable to delete user";
		}
	}

	public function logout() {
		$this->session->sess_destroy();
		return redirect(base_url('login'));
	}
}