<?php
	class Users extends CI_Model {

		public function showAllUser() {
			return $this->db->get('tbl_users')->result();
		}

		public function save($array) {
			$array['password'] = password_hash($array['password'], 1);
			return $this->db->insert('tbl_users', $array);
		}

		public function login($username, $password) {
			/*
				1 - check username
				2 - check if username has valid password
			*/
			$return = false;
			$this->db->where('username', $username);
			$user = $this->db->get('tbl_users')->row();
			$password_hash = $user->password;
			if (password_verify($password, $password_hash)) {
				$this->session->set_userdata('user', $user);
				$return = true;
			}
			return $return;
		}

		public function all() {
			return $this->db->get('tbl_users')->result();
		}

		public function delete($id) {
			$this->db->where('id', $id);
			return $this->db->delete('tbl_users');
		}
	}